<?php
namespace App\Models;


class usAbout
{
}
