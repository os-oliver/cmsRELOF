import { topNavbarComponent } from "./components/tNavBar.js";
import { heroGradient } from "./components/heroGradient.js";
import { heroVideo } from "./components/heroVideo.js";
import { featuresGrid } from "./components/featuresGrid.js";
import { testimonial } from "./components/testimonials.js";
import { contactForm } from "./components/contactForm.js";
import { footer } from "./components/footer.js";
import { pricing } from "./components/pricing.js";
import { stats } from "./components/stats.js";
import { teamSection } from "./components/teamSection.js";
import { buttonComponent } from "./components/button.js";
import { gallery } from "./components/gallery.js";
import { faqSection } from "./components/faqSection.js";
import { link } from "./components/link.js";
import { multiLink } from "./components/multinav.js";

let isUndoing = false;

const btns = {
  component: document.getElementById("component"),
  settings: document.getElementById("settingsbtn"),
  nav: document.getElementById("navbtn"),
};
const panels = {
  component: document.getElementById("blocks"),
  settings: document.getElementById("settingsBlock"),
  nav: document.getElementById("navBlock"),
};
function resetAll() {
  Object.values(btns).forEach((b) => b.classList.remove("primary"));
  Object.values(panels).forEach((p) => {
    p.style.display = "none";
    p.classList.add("hidden");
  });
}

function makeHandler(key) {
  return () => {
    resetAll();
    btns[key].classList.add("primary");
    panels[key].classList.remove("hidden");
    panels[key].style.display = "block";
  };
}
btns.component.addEventListener("click", makeHandler("component"));
btns.settings.addEventListener("click", makeHandler("settings"));
btns.nav.addEventListener("click", makeHandler("nav"));
const dynamicOptions = [
  { value: "#home", name: "Home" },
  { value: "#services", name: "Services" },
  { value: "#contact", name: "Contact" },
  { value: "https://example.com", name: "External Link" },
];
const pages = [
  { slug: "/", title: "Početna" },
  { slug: "/about", title: "O Nama" },
];

// Device buttons
document.querySelectorAll(".device-btn").forEach((btn) =>
  btn.addEventListener("click", () => {
    editor.setDevice(btn.dataset.device);
    document
      .querySelectorAll(".device-btn")
      .forEach((b) => b.classList.toggle("active", b === btn));
  })
);

const editor = grapesjs.init({
  container: "#gjs",
  fromElement: false,
  height: "100%",
  width: "auto",
  parser: {
    optionsHtml: {
      allowScripts: true,
    },
  },
  fromElement: true,

  storageManager: false,
  blockManager: { appendTo: "#blocks" },
  styleManager: { appendTo: "#settingsBlock" },

  panels: { defaults: [] },
  deviceManager: {
    devices: [
      { id: "desktop", name: "Desktop", width: "" },
      { id: "tablet", name: "Tablet", width: "768px" },
      { id: "mobile", name: "Mobile", width: "375px" },
    ],
  },
  canvas: { scripts: ["https://cdn.tailwindcss.com"] },
});

// Trait & link customization
function updateLinkType(options) {
  editor.DomComponents.removeType("link");
  editor.DomComponents.addType("link", {
    isComponent: (el) => el.tagName === "A",
    model: {
      defaults: {
        tagName: "a",
        traits: [
          { type: "select", name: "href", options },
          { type: "text", name: "title" },
          { type: "text", name: "data-role" },
          {
            type: "select",
            name: "target",
            options: [
              { value: "_self", name: "Same window" },
              { value: "_blank", name: "New window" },
            ],
          },
        ],
      },
      init() {
        this.listenTo(
          this,
          "change:href change:title change:data-role change:target",
          this.updateAttrs
        ).updateAttrs();
      },
      updateAttrs() {
        const {
          href = "#",
          title = "",
          "data-role": dr,
          target = "_self",
        } = this.attributes;
        this.setAttributes({
          href,
          title,
          target,
          ...(dr && { "data-role": dr }),
        });
      },
    },
    view: { events: { click: (e) => e.preventDefault() } },
  });
}
updateLinkType(pages.map((p) => ({ value: p.slug, name: p.title })));

/*editor.on("component:add", (model) => {
  if (model.get("tagName") !== "nav") return;

  const wrapper = editor.DomComponents.getWrapper();
  // find any other <nav> (exclude the one just added)
  const um = editor.UndoManager;

  const otherNavs = wrapper.find("nav").filter((nav) => nav.cid !== model.cid);

  if (otherNavs.length > 0) {
    // let GJS finish its add routine
    setTimeout(() => {
      // 1) stop recording
      um.stop();

      // 2) remove the orphan <nav>
      model.remove();

      console.log(um.history);
      const stack = um.getStack();

      console.log(stack);
      console.log(stack.pop());
      console.log(um.getStack());

      um.start();
    }, 0);
  }
});*/
editor.on("component:selected", (comp) => {
  if (!comp) return;
  console.log(comp.toHTML());

  // Only continue if the component is an <a> tag
  if (comp.getEl()?.tagName?.toLowerCase() === "button") {
    let parent = comp.parent();
    while (parent && !parent.getClasses().includes("megaMenu")) {
      parent = parent.parent();
    }

    if (parent) {
      console.log("Found parent with class 'megaMenu':", parent);

      const processComponent = (component) => {
        const classes = component.getClasses();
        console.log(`Checking component:`, classes);

        // Replace 'invisible' class with 'visible'
        if (classes.includes("invisible")) {
          component.removeClass("invisible");
          component.addClass("visible");
          console.log("Replaced 'invisible' with 'visible'.");
        }

        // Recursively apply to children
        const children = component.components();
        children.forEach((child) => processComponent(child));
      };

      processComponent(parent);
    } else {
      console.log("No parent with class 'megaMenu' found.");
    }
  }
});
function injectHTMLAndScripts(container, html) {
  // 1. parse the HTML
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");

  // 2. move all non-script nodes into your container
  Array.from(doc.body.childNodes).forEach((node) => {
    if (node.tagName !== "SCRIPT") {
      container.appendChild(node.cloneNode(true));
    }
  });

  // 3. find all scripts in the fetched HTML
  const scripts = doc.querySelectorAll("script");
  scripts.forEach((oldScript) => {
    const newScript = document.createElement("script");
    // if it's an external script, copy the src
    if (oldScript.src) {
      newScript.src = oldScript.src;
      // you may want to preserve async/defer, etc:
      if (oldScript.async) newScript.async = true;
      if (oldScript.defer) newScript.defer = true;
    } else {
      // inline script — copy its text
      newScript.textContent = oldScript.textContent;
    }
    document.body.appendChild(newScript);
  });
}

// Load template
const params = new URLSearchParams(location.search);
const tipUstanove = params.get("tipUstanove");
const komponenta = params.get("komponenta");

if (tipUstanove) {
  fetch(`/template?tipUstanove=${encodeURIComponent(tipUstanove)}`)
    .then((r) => (r.ok ? r.text() : Promise.reject("Not found")))
    .then((html) => editor.setComponents(html))
    .catch(console.error);
} else if (komponenta) {
  fetch(`/component?cmp=${encodeURIComponent(komponenta)}`)
    .then((r) =>
      r.ok ? r.text() : Promise.reject("Nije pronađena komponenta")
    )
    .then((html) => editor.setComponents(html))
    .catch(console.error);
} else {
  console.log("Nema ni 'tipUstanove' ni 'komponenta' parametra u URL-u.");
  // Optionally: učitaj neki default sadržaj ili prikaži upozorenje korisniku
}

// On load: reset style sectors & iframe styles
editor.on("load", () => {
  const sm = editor.StyleManager;
  sm.getSectors().reset([]);
  const head = editor.Canvas.getFrameEl().contentDocument.head;
  [
    "/output.css",
    "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css",
  ].forEach((href) =>
    head.appendChild(
      Object.assign(document.createElement("link"), { rel: "stylesheet", href })
    )
  );

  ["osnovno", "razmaci", "granice"].forEach((id) => sm.removeSector(id));

  // Standard Tailwind sectors
  [
    { id: "spacing", name: "Razmaci", buildProps: ["margin", "padding"] },
    {
      id: "typography",
      name: "Tipografija",
      buildProps: [
        "font-family",
        "font-size",
        "font-weight",
        "line-height",
        "text-align",
        "color",
      ],
    },
    {
      id: "background",
      name: "Pozadina",
      buildProps: [
        "background-color",
        "background-image",
        "background-size",
        "background-position",
      ],
    },
    {
      id: "layout",
      name: "Layout",
      buildProps: [
        "display",
        "flex-direction",
        "justify-content",
        "align-items",
        "width",
        "height",
      ],
    },
  ].forEach((cfg) => sm.addSector(cfg.id, cfg));

  // Undo/redo buttons
  const undo = document.getElementById("undo-btn"),
    redo = document.getElementById("redo-btn");
  editor.on("undo redo", () => {
    undo.disabled = !editor.UndoManager.hasUndo();
    redo.disabled = !editor.UndoManager.hasRedo();
  });
  undo.addEventListener("click", () => {
    editor.UndoManager.undo();
    isUndoing = true;
  });
  redo.addEventListener("click", () => {
    editor.UndoManager.redo();
    isUndoing = false;
  });
  function clearElements(element) {
    const newChildren = element
      .components()
      .filter((child) => child.get("tagName") === "i");

    element.components([]); // Clear all components

    newChildren.forEach((child) => element.append(child)); // Re-add only <i> elementsck
    element.components([newChildren]);
  }
  function downloadPHPFile(filename, content) {
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const link = document.createElement("a");

    link.href = URL.createObjectURL(blob);
    link.download = filename;

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
  function htmlToDynamicCode(target, type) {
    const components = target
      .components()
      .filter((child) => child.get("tagName") === "div");
    const nStartingCards = components.length;

    if (!nStartingCards) return;

    const modelDiv = components[0];
    const inputElements = modelDiv.find("[id^='g-']");

    inputElements.forEach((element) => {
      const key = element.getId().slice(2);
      const tag = element.get("tagName").toLowerCase();

      if (tag === "img") {
        clearElements(element);
        element.addAttributes({
          imageSourceGen: `<?php echo $${type}_item['${key}'] ; ?>`,
        });
      } else {
        clearElements(element);
        element.append([
          {
            type: "textnode",
            content: `<?php echo htmlspecialchars($${type}_item['${key}'] ?? '', ENT_QUOTES); ?>`,
          },
        ]);
      }
    });

    // Generate HTML string, remove old src, convert placeholder to src
    let templateHTML = modelDiv
      .toHTML()
      .replace(/\ssrc="[^"]*"/g, "")
      .replace(/imageSourceGen=/g, "src=");

    const phpLoop = `<?php $__i = 0; foreach ($${type} as $${type}_item): if ($__i++ >= ${nStartingCards}) break; ?>\n${templateHTML}\n<?php endforeach; ?>`;

    target.components([]);
    target.append([{ type: "textnode", content: phpLoop }]);
  }

  function setupElement(child, landingPageFiles) {
    const id = child.getId();
    const html = child.toHTML();
    // Number of direct children
    switch (id) {
      case "gallery": {
        const target = child
          .find("*")
          .find((model) => model.getId() === "galleryCards");
        htmlToDynamicCode(target, "images");
        const onceDecoded = child.toHTML().replace(/&amp;/g, "&"); // "&lt;?php echo 'hello'; ?&gt;"
        const fullyDecoded = onceDecoded
          .replace(/&lt;/g, "<")
          .replace(/&gt;/g, ">");
        landingPageFiles.push({
          [`landingPage/${id}.php`]: fullyDecoded,
        });
        break;
      }
      case "events": {
        const target = child
          .find("*")
          .find((model) => model.getId() === "eventsCards");
        htmlToDynamicCode(target, "events");
        const onceDecoded = child.toHTML().replace(/&amp;/g, "&"); // "&lt;?php echo 'hello'; ?&gt;"
        const fullyDecoded = onceDecoded
          .replace(/&lt;/g, "<")
          .replace(/&gt;/g, ">");
        landingPageFiles.push({
          [`landingPage/${id}.php`]: fullyDecoded,
        });
        break;
      }
      default:
        landingPageFiles.push({
          [`landingPage/${id}.php`]: child.toHTML(),
        });
    }
  }

  function navTree(target, tree, navID, dropDownclass) {
    const nav = target.find("*").find((child) => child.getId() === navID);
    console.log(nav, "nav");
    if (!nav) return;

    nav.components().forEach((comp) => {
      if (comp.get("tagName") == "a") {
        const el = comp.view.el;
        let text = el.textContent
          .trim()
          .replace(" ", "-")
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "")
          .replace(/[^\x00-\x7F]/g, "")
          .toLowerCase();

        if (text == "pocetna") text = "";
        console.log("Text inside tag:", text);
        comp.addAttributes({ href: "/" + text });
        comp.view.render();
        tree.push({ root: text });
      } else if (comp.getClasses().includes(dropDownclass)) {
        let current;
        comp.components().forEach((ch) => {
          const tag = ch.get("tagName");

          if (tag === "button") {
            console.log("element:", ch.view.el);
            const text = ch.view.el.innerText.trim();
            current = { root: text, elements: [] };
            tree.push(current);
          }

          if (tag === "div" && current) {
            ch.components().forEach((link) => {
              if (link.get("tagName") == "a") {
                console.log("element:", navID, ch.view.el.innerText);

                const el = link.view.el;
                const text = el.textContent
                  .trim()
                  .replace(" ", "-")
                  .replace(/[^\x00-\x7F]/g, "");
                console.log("Text inside tag:", text);
                console.log("curuurur:", current);
                link.addAttributes({
                  href: ("/" + current.root + "/" + text)
                    .toLowerCase()
                    .replace(" ", "-"),
                });
                link.view.render();
                current.elements.push({ root: text });
              }
            });
          }
        });
      }
    });
    console.log("poster", tree);
    return tree;
  }

  function fullPageExport() {
    // Get the root body component
    const bodyComponent = editor.DomComponents.getWrapper();
    const landingPageFiles = [];
    console.log("Direct children of <body>:");
    const tree = [];

    // Loop through only the direct children (no recursion)
    bodyComponent.components().each((child) => {
      const tag = child.get("tagName") || child.get("type");
      const name = child.getName() ? ` (${child.getName()})` : "";
      const _ = [];
      // Get classes safely
      const classList = child.get("classes");
      const classes = classList
        ? Array.from(classList)
            .map((c) => c.getName())
            .join(".")
        : "";
      switch (tag) {
        case "header":
          navTree(child, tree, "navBarID", "dropdown");
          landingPageFiles.push({
            [`landingPage/${tag}.php`]: child.toHTML(),
          });
          break;
        case "section":
          setupElement(child, landingPageFiles);
          break;
        case "footer":
          landingPageFiles.push({
            [`landingPage/${tag}.php`]: child.toHTML(),
          });
          break;
        case "div":
          if (child.getId() == "mobileMenu")
            navTree(child, _, "navBarIDm", "mobile-dropdown");
          landingPageFiles.push({
            [`landingPage/${tag}${child.getId()}.php`]: child.toHTML(),
          });
      }
    });
    console.log(landingPageFiles);
    console.log("stablo:", tree);
    const css = editor.getCss();
    const fullHtml = editor.getHtml();

    const scripts = fullHtml.match(/<script[\s\S]*?<\/script>/gi) || [];

    const js = scripts.join("\n").replace(/&lt;/g, "<").replace(/&gt;/g, ">");
    console.log("sccc", js);

    let endpoint = "";

    fetch("/savePage", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        css: css,
        components: landingPageFiles,
        tree: tree,
        js: js,
      }),
    })
      .then((r) => r.text())
      .then((msg) => alert(msg))
      .catch((err) => alert("Error: " + err));
  }
  document.getElementById("export").addEventListener("click", async () => {
    if (komponenta) {
      const wrapper = editor.DomComponents.getWrapper();

      // 1) collect all <section> HTML
      const sections = [];
      const traverse = (components) => {
        components.each((comp) => {
          if (comp.get("tagName") === "section") {
            sections.push(comp);
          }
          if (comp.components().length) {
            traverse(comp.components());
          }
        });
      };
      traverse(wrapper.components());
      const combinedHTML = sections.map((s) => s.toHTML()).join("");

      // --- here’s the fetch to send it ---
      // replace this with your actual component name

      // Use FormData so PHP $_POST picks it up automatically
      const formData = new FormData();
      formData.append("cmp", komponenta);
      formData.append("html", combinedHTML);

      try {
        const res = await fetch("/saveComponent", {
          method: "POST",
          body: formData,
        });

        if (!res.ok) {
          const text = await res.text();
          throw new Error(`Server error (${res.status}): ${text}`);
        }

        const json = await res.json();
        console.log("Saved successfully:", json);
        alert("Component saved! Bytes written: " + json.bytes_written);
      } catch (err) {
        console.error("Save failed:", err);
        alert("Error saving component: " + err.message);
      }
    } else if (tipUstanove) {
      fullPageExport();
    }
  });

  editor.on("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && ["z", "y"].includes(e.key)) {
      e.preventDefault();
      alert("Koristite dugmad Poništi/Ponovi na alatnoj traci!");
    }
  });
});

// Register blocks
Object.entries({
  heroGradient,
  heroVideo,
  topNavbarComponent,
  featuresGrid,
  testimonial,
  contactForm,
  footer,
  pricing,
  stats,
  teamSection,
  buttonComponent,
  gallery,
  faqSection,
  link,
  multiLink,
}).forEach(([name, block]) =>
  editor.BlockManager.add(name.replace(/([A-Z])/g, "-$1").toLowerCase(), block)
);
